RaceIQ 4 November 2026. Isolated single recovery attempt on 10 November. Original shared archives and previously delivered empty export retained unchanged. No racing models/actions run.
