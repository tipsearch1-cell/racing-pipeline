RaceIQ export: 12–15 October 2026 inclusive, GB and Ireland.
Contains raw metric and sectional JSONL, race inventory and a normalized runner CSV.
The 2026 filenames describe the source schema; contents are restricted to the requested four days.
12–14 October use existing archived scrapes. 15 October was fetched from published completed-race results for this delivery only.
COVERAGE.csv reports actual race and runner counts by day. UNAVAILABLE.json lists absent RaceIQ responses; no missing data is fabricated.
Today is a snapshot, not a promise that every race or delayed sectional has been published.
One response per race/kind, preferring successful payloads; normalized runner keys are unique.
No historic archives, production model, picks or stakes were modified.
