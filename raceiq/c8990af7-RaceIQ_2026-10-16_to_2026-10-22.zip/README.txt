RaceIQ export: 2026-10-16 through 2026-10-22 inclusive. GB + Ireland, all collected race codes.
Contains 2442 parsed runner rows across 235 races.
RaceIQ_runner_data.csv = combined selected native normalized runner data.
parsed_by_date/ = identical data split by race date. Do not concatenate both and double count.
RaceIQ_race_inventory.csv = discovered completed-race inventory, not proof of universal provider coverage.
raw/ = date-filtered original JSONL capture lines, bytes preserved; retries/duplicates retained and audited.

The collector refreshed at 2026-10-22T08:00:01Z. There is no captured data for 2026-10-22 in that morning snapshot. This is NOT a claim that the provider has no data or that today's eventual racing is complete. No current-day results are invented. See coverage for per-day available counts and any inventory-vs-parsed gaps.

All measured metrics/sectionals, finish positions, times, relative ranks and outcomes are POST-RACE data, not same-race pre-off predictors. The archived normalized CSV uses the last raw capture per race for each endpoint; this export preserves those normalized values without rebuilding them. Original raw files remain unchanged. Raw captures are parsed JSON response wrappers, not byte-identical HTTP bodies. Race dates are not publication timestamps. Source hashes/mtimes and the daily refresh receipt are in COVERAGE_AND_PROVENANCE.json.
No lagged training features supplied and no production/models/picks/stakes changed.
