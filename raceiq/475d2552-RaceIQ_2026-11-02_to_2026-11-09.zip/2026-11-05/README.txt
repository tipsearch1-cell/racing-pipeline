RaceIQ daily export: 2026-11-05, GB and Ireland.
Raw metric and sectional JSONL, race inventory and normalized runner CSV.
Source is the archived daily collection; no sources or model files modified.
COVERAGE.csv contains actual counts; UNAVAILABLE.json lists missing responses.
Delayed provider publication can mean partial coverage; absent data is never fabricated.
