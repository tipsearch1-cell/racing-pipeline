RaceIQ archived export: 2-9 November 2026 inclusive. Daily normalized CSVs, raw metrics and sectionals, inventories, coverage and manifests.
IMPORTANT: 4 November has no archived data. Its collector inventory lookup timed out; this is a coverage gap, not a confirmed no-racing day. Other dates have no unavailable responses recorded. Original daily exports retained unchanged.
