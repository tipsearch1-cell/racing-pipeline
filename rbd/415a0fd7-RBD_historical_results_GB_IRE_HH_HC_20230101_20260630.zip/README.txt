RBD GB + IRE handicap hurdles and handicap chases: 2023-01-01 to 2026-06-30 inclusive.
Package: historical_results. Runner rows: 97018.
Includes Handicap Hurdle, Novice Hcap Hurdle, Handicap Chase, Novice Hcap Chase.

Pre-race CSVs are filtered CURRENT-DAY native Combined-sheet runner rows extracted from archived Daily workbooks, not the unchanged workbooks or their full horse-history rows. Native current result fields were checked blank (or NR). Date/time values are rendered as ISO/clock text. Source SHA/path columns were added. These provider archives were retrieved retrospectively; original pre-off receipt timing is not independently certified. No result features were joined into pre-race rows. Eight Christmas-period dates have no listed Daily archive; see coverage. Zero-row available cards are explicitly distinguished from unlisted files.

Historical results package is the complete four native member-dashboard exports (original XLSX + CSV), providing retrospective outcomes, ratings and scope, NOT genuine pre-off feature snapshots. Native daily results package, when provided separately, includes original timed-odds columns. Its scope_country/scope_race_type metadata is explicitly joined from dashboard identities because native Results sheets do not contain Country/Type.

Pre-race entrants and results differ because of nonrunners, reserves, abandoned cards, source omissions and source identity differences. Missing identities are listed, not synthesized. Raw-source manifests reference original immutable files retained on the collector; original XLSX archives are supplied separately. Do not use post-race labels/timed odds as same-race pre-off features.
No production/model/pick/stake changes. Each ZIP is independently readable and under 400,000,000 bytes.
