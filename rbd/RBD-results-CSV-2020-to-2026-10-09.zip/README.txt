RBD results CSV exports: 28 quarters, 403,563 runner rows, 2020-01-01 through 2026-10-09. CSV versions of the original Excel exports.
Scope: GB Flat-candidate race types; broad Maiden/Listed categories may include Jumps. Not all-country/all-racing coverage. 2026 Q4 is partial through 9 October. Derived RaceIQ joins/model outputs excluded.
