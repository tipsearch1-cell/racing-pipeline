racedata original source exports, snapshot 2026-10-14 UTC.
Includes original uploads, automated daily exports and, for RaceData, settled/backfilled results.
Byte-identical copies stored once; MANIFEST.csv maps every located source to its archived file.
Different versions of the same date are retained. No merged or model-generated datasets, test fixtures, code or credentials.
Searched: Frankie data/, racing/raw/, McCoy workspace, main workspace data/, OpenClaw inbound uploads.
