from pathlib import Path
import json,sys,hashlib
import numpy as np,pandas as pd,lightgbm as lgb
from catboost import CatBoostRanker,Pool
from scipy.special import logit,logsumexp
from scipy.optimize import minimize_scalar,minimize
R=Path('/root/.openclaw/workspace-frankie');sys.path.insert(0,str(R));O=Path(__file__).parent
from tools.freeze_rich_step1_dynamic_shadow import SPEED_FEATURES
from tools.compare_flat_step1_four_models import FEATURES
from tools.run_locked_flat_model_backtest import CATS_PRICE,fit
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
z=pd.read_pickle(O/'pre_result_features.pkl');t=pd.read_csv(R/'reports/sanitized_april_monthly_replay_2026-10-04/outcome_truth_separate.csv');t=t[t.runner_key.str[:10]<'2026-10-01'][['runner_key','win','ran']]
pred=[];audits=[];blocked=[]
for month in ['2026-09','2026-10']:
 previous=(pd.Timestamp(month+'-01')-pd.DateOffset(months=1)).strftime('%Y-%m')
 for code in ['Flat','Jumps']:
  tr=z[z.code.eq(code)&z.date.str.startswith(previous)].merge(t,on='runner_key',how='left',validate='one_to_one').sort_values(['race_key','runner_key']).reset_index(drop=True);test=z[z.code.eq(code)&z.date.str.startswith(month)].sort_values(['race_key','runner_key']).reset_index(drop=True)
  minimum=40 if code=='Flat' else 25
  if tr.race_key.nunique()<minimum or len(test)==0:blocked.append({'code':code,'month':month,'reason':'insufficient supported previous-month full fields','training_fields':tr.race_key.nunique(),'minimum':minimum});continue
  assert tr.win.notna().all() and tr.groupby('race_key').win.sum().eq(1).all();tr['target_win']=tr.win.astype(int)
  rd=tr.groupby('race_key').date.first().sort_values();cut=rd.iloc[int(len(rd)*.7)];a=tr[tr.date<cut];v=tr[tr.date>=cut]
  if a.race_key.nunique()<(30 if code=='Flat' else 15) or v.race_key.nunique()<(10 if code=='Flat' else 5):blocked.append({'code':code,'month':month,'reason':'insufficient forward calibration split'});continue
  assert a.date.max()<v.date.min() and tr.date.max()<test.date.min()
  native=SPEED_FEATURES if code=='Flat' else FEATURES
  fsmap=json.load(open(O/'variants.json'))
  def catframe(d,fs):
   x=d[fs].copy()
   for c in [c for c in CATS_PRICE if c in fs]:x[c]=x[c].astype(object).where(x[c].notna(),'UNK').astype(str)
   return x
  def fitm(d,fs):
   if code=='Flat':
    x=d.copy()
    for c in [c for c in CATS_PRICE if c in fs]:x[c]=x[c].astype(object).where(x[c].notna(),'UNK').astype(str).astype('category')
    return fit(x,fs,[c for c in CATS_PRICE if c in fs])
   m=CatBoostRanker(iterations=300,depth=4,learning_rate=.05,l2_leaf_reg=5,loss_function='YetiRank',random_seed=42,thread_count=2,verbose=False,allow_writing_files=False);m.fit(Pool(catframe(d,fs),label=d.target_win,group_id=d.race_key.astype(str),cat_features=[c for c in CATS_PRICE if c in fs]));return m
  def score(m,d,fs):
   if code=='Flat':
    x=d.copy()
    for c in [c for c in CATS_PRICE if c in fs]:x[c]=x[c].astype(object).where(x[c].notna(),'UNK').astype(str).astype('category')
    return logit(np.clip(m.predict(x[fs]),1e-9,1-1e-9))
   return m.predict(catframe(d,fs))
  for arm,fs in fsmap.items():
   cm=fitm(a,fs);ss=score(cm,v,fs);yy=v.target_win.to_numpy();groups=list(v.groupby('race_key',sort=False).indices.values());opt=minimize_scalar(lambda temp:np.mean([logsumexp(ss[ix]*temp)-np.dot(yy[ix],ss[ix]*temp) for ix in groups]),bounds=(.1,3),method='bounded');assert opt.success
   vm=np.log(v.industry_prob.to_numpy());tm=np.log(test.industry_prob.to_numpy())
   def objective(co):
    u=ss*opt.x*co[0]+vm*co[1]
    return np.mean([logsumexp(u[ix])-np.dot(yy[ix],u[ix]) for ix in groups])+.01*((co[0])**2+(co[1]-1)**2)
   blend=minimize(objective,[.2,1.],bounds=[(0,3),(.1,3)],method='L-BFGS-B');assert blend.success
   m=fitm(tr,fs);mp=O/f'{code}_{arm}_{month}{".txt" if code=="Flat" else ".cbm"}';m.save_model(str(mp))
   q=test[['date','code','race_key','runner_key','RTR__Win Odds','RTR__RTR Rank','Racedata__PR Rank','evidence_tier']].copy();q['arm']=arm;q['month']=month;q['log_score']=score(m,test,fs)*opt.x;q['probability']=np.exp(q.log_score-q.groupby('race_key').log_score.transform(lambda s:logsumexp(s.to_numpy())));q['model_rank']=q.groupby('race_key').log_score.rank(method='first',ascending=False).astype(int);pred.append(q)
   qb=q.copy();qb['arm']=arm+'__blend';qb['log_score']=q.log_score*blend.x[0]+tm*blend.x[1];qb['probability']=np.exp(qb.log_score-qb.groupby('race_key').log_score.transform(lambda u:logsumexp(u.to_numpy())));qb['model_rank']=qb.groupby('race_key').log_score.rank(method='first',ascending=False).astype(int);pred.append(qb)
   audits.append({'code':code,'month':month,'arm':arm,'features':fs,'train_races':tr.race_key.nunique(),'train_through':tr.date.max(),'calibration_train_through':a.date.max(),'calibration_from':v.date.min(),'calibration_through':v.date.max(),'temperature':opt.x,'blend_coefficients':blend.x.tolist(),'model_file':mp.name,'model_sha256':sha(mp)})
   print('FITTED',code,month,arm,flush=True)
  if code=='Flat':
   marketss=np.log(v.industry_prob.to_numpy());mg=list(v.groupby('race_key',sort=False).indices.values());my=v.target_win.to_numpy()
   mo=minimize_scalar(lambda temp:np.mean([logsumexp(marketss[ix]*temp)-np.dot(my[ix],marketss[ix]*temp) for ix in mg])+.01*(temp-1)**2,bounds=(.1,3),method='bounded');assert mo.success
   for label,coef in [('market_proportional',1.),('market_calibrated',mo.x)]:
    q=test[['date','code','race_key','runner_key','RTR__Win Odds','RTR__RTR Rank','Racedata__PR Rank','evidence_tier']].copy();q['arm']=label;q['month']=month;q['log_score']=np.log(test.industry_prob.to_numpy())*coef;q['probability']=np.exp(q.log_score-q.groupby('race_key').log_score.transform(lambda u:logsumexp(u.to_numpy())));q['model_rank']=q.groupby('race_key').log_score.rank(method='first',ascending=False).astype(int);pred.append(q)
   from scipy.optimize import brentq
   q=q.copy();q['arm']='market_power';q['probability']=np.nan
   for _,ix in test.groupby('race_key',sort=False).indices.items():
    raw=test.iloc[ix].industry_prob.to_numpy();k=brentq(lambda k:(raw**k).sum()-1,.001,100);q.iloc[ix,q.columns.get_loc('probability')]=raw**k
   q['log_score']=np.log(q.probability);q['model_rank']=q.groupby('race_key').log_score.rank(method='first',ascending=False).astype(int);pred.append(q)
p=pd.concat(pred,ignore_index=True);p.to_csv(O/'predictions_pre_result.csv',index=False);books=[]
for (code,month,arm),g in p.groupby(['code','month','arm']):
 gate=g.model_rank.le(2)&g['RTR__RTR Rank'].between(1,3)&g['Racedata__PR Rank'].between(1,3);n=gate.groupby(g.race_key).transform('sum')
 for lane,mask in [('top1',g.model_rank.eq(1)),('shadow_rules',gate&(n.eq(1) if code=='Flat' else True)&g['RTR__Win Odds'].ge(3))]:
  b=g[mask].copy();b['lane']=lane;b['stake']=1.;books.append(b)
pd.concat(books).to_csv(O/'final_nominees_pre_result.csv',index=False);(O/'models.json').write_text(json.dumps(audits,indent=2));(O/'blocked.json').write_text(json.dumps(blocked,indent=2));(O/'prediction_seal.json').write_text(json.dumps({'forecast_sha256':sha(O/'predictions_pre_result.csv'),'nominees_sha256':sha(O/'final_nominees_pre_result.csv'),'models_sha256':sha(O/'models.json'),'prior_only':True},indent=2))
