from pathlib import Path
import pandas as pd,numpy as np,json,hashlib,sys,itertools
R=Path('/root/.openclaw/workspace-frankie');sys.path.insert(0,str(R));O=Path(__file__).parent;P=R/'reports/step1_small_rating_block/2026-10-11';A=R/'reports/step1_rating_relative_audit/2026-10-11'
from tools.test_flat_lgb_rbd_feature_ablation import key
from tools.freeze_rich_step1_dynamic_shadow import SPEED_FEATURES
from tools.run_locked_flat_model_backtest import CATS_PRICE
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=json.load(open(P/'SPECIFICATION.json'));sources=spec['sources']+ [{'path':str(A/'pre_result_features.pkl'),'sha256':H(A/'pre_result_features.pkl')},{'path':str(P/'pre_result_features.pkl'),'sha256':H(P/'pre_result_features.pkl')}]
for s in sources:assert H(s['path'])==s['sha256']
d=pd.read_pickle(P/'pre_result_features.pkl');a=pd.read_pickle(A/'pre_result_features.pkl')
cols=['PR__raw','RTR__raw','RTR_R1__raw','RTR_AV3__raw','RTR_AV10__raw','RBD__raw']
d=d.merge(a[['runner_key']+cols],how='left',on='runner_key',validate='one_to_one')
for s in sources:
 p=Path(s['path'])
 if 'rtr' in p.name.lower() and p.suffix=='.csv' and '2026-10-' in str(p):
  x=pd.read_csv(p,skiprows=1,low_memory=False)
  if not {'Course name','R1','AV3','AV10','RTR Score','Position'}<=set(x):continue
  day=next((v for v in pd.unique(d.date) if v in str(p)),None)
  if day is None:continue
  assert pd.to_numeric(x.Position,errors='coerce').notna().sum()==0
  x['runner_key']=key(pd.DataFrame({'Date':day,'Track':x['Course name'],'Time':x['Course time'],'Horse':x['Horse name']}))
  x=x.set_index('runner_key');assert not x.index.duplicated().any()
  m=d.date.eq(day)
  for out,raw in [('RTR__raw','RTR Score'),('RTR_R1__raw','R1'),('RTR_AV3__raw','AV3'),('RTR_AV10__raw','AV10')]:d.loc[m,out]=d.loc[m,'runner_key'].map(pd.to_numeric(x[raw],errors='coerce'))
  d.loc[m,'PR__raw']=np.expm1(d.loc[m,'pr_score_log'])
  d.loc[m,'RBD__raw']=d.loc[m,'RBD Rating']
bad=d[cols].isna().any(axis=1);reject=set(d.loc[bad,'race_key']);pd.DataFrame({'race_key':sorted(reject),'reason':'missing at least one of six ratings'}).to_csv(O/'exclusions.csv',index=False);d=d[~d.race_key.isin(reject)].copy();assert d[cols].notna().all().all()
d.to_pickle(O/'pre_result_features.pkl')
market=['industry_prob','field_market_prob_sum','market_rank_in_race','market_prob_gap_to_fav','market_top2_share','market_top3_share']
conditions=['Track','Going','Racetype','Class','Dist (F)','Cla diff since LTO','Prev Races','Days Since LTO','field_prev_races_mean','prev_races_vs_mean','field_days_mean','days_vs_mean','Course Winner','Distance Winner','Up in Trip','OR diff since LTO']
base=[f for f in SPEED_FEATURES if f not in market+['pr_score_log','Racedata__PR Rank']]
variants={}
for with_conditions in [False,True]:
 for n in range(7):
  for subset in itertools.combinations(cols,n):
   name=('B' if with_conditions else 'A')+'__'+('_'.join(c.split('__')[0] for c in subset) if subset else 'none')
   variants[name]=[f for f in base if with_conditions or f not in conditions]+list(subset)
(O/'variants.json').write_text(json.dumps(variants,indent=2))
spec.update({'sources':sources,'arms':len(variants),'rating_inputs':cols,'removed_market_features':market,'conditions_form_block':conditions,'important':'Existing Step1 form/conditions proxies only, not comprehensive past-performance suitability. Dynamic speed retained and may itself contain conditions; OR retained including field derivatives. All 63 nonempty rating subsets, fixed raw representation; no cherry-picked representation sweep. No provider formula reconstruction. Exploratory reused outcomes, no promotion.'})
(O/'SPECIFICATION.json').write_text(json.dumps(spec,indent=2))
print(d.groupby(['code',d.date.str[:7]]).race_key.nunique().to_string(),len(variants))
