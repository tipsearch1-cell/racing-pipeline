from pathlib import Path
import sys,json,hashlib,zipfile
import pandas as pd,numpy as np,lightgbm as lgb
from scipy.special import logit
from catboost import CatBoostRanker
R=Path('/root/.openclaw/workspace-frankie');sys.path.insert(0,str(R));O=Path(__file__).parent
from tools.run_locked_flat_model_backtest import CATS_PRICE
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
seal=json.load(open(O/'prediction_seal.json'));assert H(O/'predictions_pre_result.csv')==seal['forecast_sha256'];assert H(O/'final_nominees_pre_result.csv')==seal['nominees_sha256'];p=pd.read_csv(O/'predictions_pre_result.csv');b=pd.read_csv(O/'final_nominees_pre_result.csv')
t=pd.read_csv(R/'reports/sanitized_april_monthly_replay_2026-10-04/outcome_truth_separate.csv');t=t[t.runner_key.str[:10]<'2026-10-01'].copy()
october=pd.read_csv(R/'reports/step1_regularized_market_blend/2026-10-11/probabilities_with_separate_truth.csv');october=october[october.arm.eq('current')][['runner_key','win','ran','betfair_sp_result']].rename(columns={'betfair_sp_result':'result_bsp'})
t=pd.concat([t,october],ignore_index=True);assert not t.runner_key.duplicated().any()
z=p.merge(t,on='runner_key',how='left',validate='many_to_one');control=z[z.arm.eq('A__none')];good=control.groupby('race_key').apply(lambda x:x.ran.notna().all() and x.win.sum()==1 and x.loc[x.win.eq(True),'result_bsp'].notna().all(),include_groups=False);valid=set(good[good].index);z=z[z.race_key.isin(valid)].copy()
z['active_p']=z.probability/z.where(z.ran).groupby(['arm','race_key']).probability.transform('sum');z['loss']=np.where(z.ran&z.win,-np.log(z.active_p.clip(lower=1e-15)),0);z['brier']=np.where(z.ran,(z.active_p-z.win.astype(float))**2,np.nan)
b=b[b.race_key.isin(valid)].merge(t,on='runner_key',how='left',validate='many_to_one');b['gross_bsp_pl']=np.where(~b.ran,0,np.where(b.win,b.result_bsp-1,-1));b.to_csv(O/'settled_books.csv',index=False)
race=z.groupby(['code','month','date','race_key','arm']).agg(logloss=('loss','sum'),brier=('brier','mean')).reset_index();race.to_csv(O/'race_metrics.csv',index=False)
rows=[];returns=[];pairs=[]
for (code,month,arm),g in z.groupby(['code','month','arm']):
 rr=race[(race.code==code)&(race.month==month)&(race.arm==arm)];rows.append({'code':code,'month':month,'arm':arm,'fields':g.race_key.nunique(),'active':int(g.ran.sum()),'winner_logloss':rr.logloss.mean(),'brier':rr.brier.mean(),'top1_wins':int(g[g.model_rank.eq(1)&g.ran].win.sum()),'top2_wins':int(g[g.model_rank.le(2)&g.ran].win.sum())})
 for lane in ['top1','shadow_rules']:
  q=b[(b.code==code)&(b.month==month)&(b.arm==arm)&(b.lane==lane)];returns.append({'code':code,'month':month,'arm':arm,'lane':lane,'nominated':len(q),'ran':int(q.ran.sum()),'wins':int(q.win.sum()),'gross_bsp_pl':q.gross_bsp_pl.sum(),'without_largest_win':q.gross_bsp_pl.sum()-max(0,q.gross_bsp_pl.max()) if len(q) else 0})
 base=race[(race.code==code)&(race.month==month)&race.arm.eq('A__none')].set_index('race_key');x=rr.set_index('race_key');assert set(x.index)==set(base.index)
 diff=x.logloss-base.logloss;daily=pd.DataFrame({'date':base.date,'delta':diff}).groupby('date').delta.agg(['sum','count']);rng=np.random.default_rng(11934);ix=rng.integers(0,len(daily),size=(10000,len(daily)));boot=daily['sum'].to_numpy()[ix].sum(1)/daily['count'].to_numpy()[ix].sum(1);lo,hi=np.quantile(boot,[.025,.975]);pairs.append({'code':code,'month':month,'arm':arm,'loss_delta':diff.mean(),'unadjusted_low95':lo,'unadjusted_high95':hi})
s=pd.DataFrame(rows);ret=pd.DataFrame(returns);pa=pd.DataFrame(pairs)
clv=b[b.ran & b.result_bsp.gt(0)].copy();clv['log_clv']=np.log(clv['RTR__Win Odds']/clv.result_bsp)
clv=clv.groupby(['code','month','arm','lane']).log_clv.mean().rename('mean_log_clv').reset_index();clv['geometric_clv']=np.expm1(clv.mean_log_clv)
ret=ret.merge(clv,on=['code','month','arm','lane'],how='left',validate='one_to_one')

for df,name in [(s,'accuracy_summary.csv'),(ret,'paper_returns.csv'),(pa,'paired_loss_differences.csv')]:df.to_csv(O/name,index=False)
d=pd.read_pickle(O/'pre_result_features.pkl');assert np.allclose(d.rbd_vs_mean,d['RBD Rating']-d.groupby('race_key')['RBD Rating'].transform('mean'));checks=1;maxerr=0
for doc in json.load(open(O/'models.json')):
 assert doc['train_through']<doc['month']+'-01' and doc['calibration_train_through']<doc['calibration_from'] and doc['calibration_through']<doc['month']+'-01';checks+=1
 mp=O/doc['model_file'];assert H(mp)==doc['model_sha256'];checks+=1
 sample=d[d.code.eq(doc['code'])&d.date.str.startswith(doc['month'])].sort_values(['race_key','runner_key']).head(30).copy();fs=doc['features']
 for c in CATS_PRICE:sample[c]=sample[c].astype(object).where(sample[c].notna(),'UNK').astype(str)
 if doc['code']=='Flat':
  for c in CATS_PRICE:sample[c]=sample[c].astype('category')
  m=lgb.Booster(model_file=str(mp));assert m.feature_name()==[f.replace(' ','_') for f in fs];score=logit(np.clip(m.predict(sample[fs],num_threads=1),1e-9,1-1e-9))
 else:m=CatBoostRanker();m.load_model(str(mp));assert m.feature_names_==fs;score=m.predict(sample[fs],num_threads=1)
 expect=p[(p.arm==doc['arm'])&(p.code==doc['code'])&(p.month==doc['month'])].set_index('runner_key').loc[sample.runner_key].log_score.to_numpy();err=np.max(np.abs(score*doc['temperature']-expect));maxerr=max(maxerr,float(err));assert err<1e-10;checks+=1
 assert doc['features']==json.load(open(O/'variants.json'))[doc['arm']]
 assert 'dynamic_speed' in doc['features'] and not set(doc['features'])&set(json.load(open(O/'SPECIFICATION.json'))['removed_market_features'])
 checks+=1
 coeff=doc['blend_coefficients'];bs=score*doc['temperature']*coeff[0]+np.log(sample.industry_prob.to_numpy())*coeff[1]
 actual=p[(p.arm==doc['arm']+'__blend')&(p.code==doc['code'])&(p.month==doc['month'])].set_index('runner_key').loc[sample.runner_key].log_score.to_numpy()
 assert np.max(np.abs(bs-actual))<1e-10;checks+=1
for item in json.load(open(O/'SPECIFICATION.json'))['sources']:assert H(item['path'])==item['sha256'];checks+=1
for item in json.load(open(O/'raw_PR_verification.json')):assert H(item['source'])==item['sha256'] and item['raw_PR_matches_reconstructed'];checks+=1

assert np.allclose(p.groupby(['arm','race_key']).probability.sum(),1);checks+=1
assert np.isclose(b.gross_bsp_pl.sum(),(b[b.ran&b.win].result_bsp-1).sum()-len(b[b.ran&~b.win]));checks+=1
v={'status':'PASS','checks':checks,'saved_score_error':maxerr,'shared_full_fields':True,'separate_outcome_join':True,'no_live_changes':True,'blocked':json.load(open(O/'blocked.json'))};(O/'verification.json').write_text(json.dumps(v,indent=2))

# Explicit matched factorial contrasts, including rating increment AFTER the market blend.
rr=race.set_index(['month','arm','race_key']);out=[]
arms=list(json.load(open(O/'variants.json')))
def compare(month, arm, control, question):
 x=race[(race.month==month)&(race.arm==arm)].set_index('race_key');base=race[(race.month==month)&(race.arm==control)].set_index('race_key')
 assert set(x.index)==set(base.index)
 delta=x.logloss-base.logloss
 daily=pd.DataFrame({'date':base.date,'delta':delta}).groupby('date').delta.agg(['sum','count'])
 rng=np.random.default_rng(11942);ix=rng.integers(0,len(daily),size=(10000,len(daily)));bt=daily['sum'].to_numpy()[ix].sum(1)/daily['count'].to_numpy()[ix].sum(1)
 lo,hi=np.quantile(bt,[.025,.975]);out.append({'month':month,'arm':arm,'control':control,'question':question,'loss_delta':delta.mean(),'unadjusted_low95':lo,'unadjusted_high95':hi})
for month in sorted(race.month.unique()):
 for suffix in ['', '__blend']:
  compare(month,'B__none'+suffix,'A__none'+suffix,'explicit form_conditions increment')
  for arm in arms:
   if arm.endswith('__none'):continue
   baseline=arm[0]+'__none'+suffix
   compare(month,arm+suffix,baseline,'ratings beyond existing inputs')
   if arm.startswith('B__'):
    compare(month,arm+suffix,'A'+arm[1:]+suffix,'conditions beyond ratings')
 for arm in arms:
  compare(month,arm+'__blend','market_calibrated','increment beyond calibrated market')
  compare(month,arm+'__blend','market_power','comparison versus power market')
con=pd.DataFrame(out);con.to_csv(O/'factorial_contrasts.csv',index=False)
picked=['A__none','B__none','A__PR_RTR_RTR_R1_RTR_AV3_RTR_AV10_RBD','B__PR_RTR_RTR_R1_RTR_AV3_RTR_AV10_RBD','market_calibrated','market_power']
picked=picked+[a+'__blend' for a in picked if not a.startswith('market')]
short=s[s.arm.isin(picked)]
report='RATINGS / CONDITIONS FULL FACTORIAL AUDIT\n\nSix raw channels PR Score, RTR Score, R1, AV3, AV10, Daily RBD Rating. Every one of 63 nonempty subsets, each with and without 16 existing form/conditions columns. Two rating-free controls. 128 fundamental configurations, each separately combined with the market using earlier forward validation only. Three market controls. Flat Dynamic speed and OR retained. This is NOT an OR-only model: other non-provider non-market inputs remain fixed. Dynamic speed can itself encode suitability. This audits explicit Step1 proxies, NOT all possible conditions knowledge or provider formulas.\n\nTraining strictly prior calendar month; forward70/30 past dates for temperature and two-stage ridge blend. Fixed architectures, raw rating representations and gates; no tuning to evaluation results. September archived blank-result inputs are not certified pre-off captures. October sealed inputs but outcomes already reused. No fresh prospective proof; 128-arm search is exploratory; all reported 95% intervals unadjusted for multiple comparisons.\n\nSUMMARY\n'+short.to_string(index=False)+'\n\nPAPER SHADOW RETURNS (overlapping alternatives; not additive)\n'+ret[ret.arm.isin(picked)&ret.lane.eq('shadow_rules')].to_string(index=False)+'\n\nFull per-rating/subset/market contrasts in factorial_contrasts.csv; all configurations in accuracy_summary.csv; full nominees and settlement ledger retained. Historical later PR/RTR agreement gates kept only for like-for-like paper book; they remain provider-dependent and are not an independent ratings-free strategy.\n\nVERIFICATION\n'+json.dumps(v,indent=2)+'\nNo live card, production, shadow fit, scheduler or trial changed. Jumps blocked, not zero performance.\n'
(O/'REPORT.txt').write_text(report)
with zipfile.ZipFile(O/'Factorial_Audit.zip','w',zipfile.ZIP_DEFLATED) as zz:
 for name in ['REPORT.txt','SPECIFICATION.json','variants.json','accuracy_summary.csv','factorial_contrasts.csv','paper_returns.csv','verification.json','blocked.json','models.json','exclusions.csv','build.py','run.py','evaluate.py','match_market_control.py','market_control_fit.json','raw_PR_verification.json']:
  zz.write(O/name,name)
with zipfile.ZipFile(O/'Factorial_Audit.zip') as zz:
 for name in zz.namelist():assert zz.read(name)==(O/name).read_bytes()
(O/'artifact_manifest.json').write_text(json.dumps({str(f.relative_to(O)):H(f) for f in O.iterdir() if f.is_file() and f.name!='artifact_manifest.json'},indent=2))
print(short.to_string(index=False));print(v)
