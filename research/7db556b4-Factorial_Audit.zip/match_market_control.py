from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp
O=Path(__file__).parent;R=Path('/root/.openclaw/workspace-frankie')
p=pd.read_csv(O/'predictions_pre_result.csv');d=pd.read_pickle(O/'pre_result_features.pkl');t=pd.read_csv(R/'reports/sanitized_april_monthly_replay_2026-10-04/outcome_truth_separate.csv')[['runner_key','win']]
audit=[]
for month in ['2026-09','2026-10']:
 previous=(pd.Timestamp(month+'-01')-pd.DateOffset(months=1)).strftime('%Y-%m')
 tr=d[d.code.eq('Flat')&d.date.str.startswith(previous)].merge(t,on='runner_key',validate='one_to_one').sort_values(['race_key','runner_key'])
 rd=tr.groupby('race_key').date.first().sort_values();cut=rd.iloc[int(len(rd)*.7)];v=tr[tr.date>=cut]
 ss=np.log(v.industry_prob.to_numpy());yy=v.win.to_numpy();groups=list(v.groupby('race_key',sort=False).indices.values())
 opt=minimize_scalar(lambda c:np.mean([logsumexp(ss[ix]*c)-np.dot(yy[ix],ss[ix]*c) for ix in groups])+.01*(c-1)**2,bounds=(.1,3),method='bounded');assert opt.success
 mask=p.arm.eq('market_calibrated')&p.month.eq(month);q=p.loc[mask].copy();q['log_score']=np.log(q.runner_key.map(d.set_index('runner_key').industry_prob))*opt.x;q['probability']=np.exp(q.log_score-q.groupby('race_key').log_score.transform(lambda s:logsumexp(s.to_numpy())));q['model_rank']=q.groupby('race_key').log_score.rank(method='first',ascending=False).astype(int);p.loc[mask,q.columns]=q
 audit.append({'month':month,'fit_from':v.date.min(),'fit_through':v.date.max(),'fields':v.race_key.nunique(),'coefficient':opt.x,'ridge':.01})
p.to_csv(O/'predictions_pre_result.csv',index=False)
books=[]
for (code,month,arm),g in p.groupby(['code','month','arm']):
 gate=g.model_rank.le(2)&g['RTR__RTR Rank'].between(1,3)&g['Racedata__PR Rank'].between(1,3);n=gate.groupby(g.race_key).transform('sum')
 for lane,mask in [('top1',g.model_rank.eq(1)),('shadow_rules',gate&(n.eq(1) if code=='Flat' else True)&g['RTR__Win Odds'].ge(3))]:
  b=g[mask].copy();b['lane']=lane;b['stake']=1.;books.append(b)
pd.concat(books).to_csv(O/'final_nominees_pre_result.csv',index=False)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
(O/'market_control_fit.json').write_text(json.dumps(audit,indent=2))
(O/'prediction_seal.json').write_text(json.dumps({'forecast_sha256':H(O/'predictions_pre_result.csv'),'nominees_sha256':H(O/'final_nominees_pre_result.csv'),'models_sha256':H(O/'models.json'),'prior_only':True},indent=2))
